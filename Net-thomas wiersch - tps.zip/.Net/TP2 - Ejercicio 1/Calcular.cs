﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2.TP2.Ejercicio1
{
    interface Calcular
    {
        double CalcularArea();
        double CalcularPerimetro();

    }
}
